# Zero-Waste Grocery — Agentic Inventory Prototype

A responsive React + TypeScript dashboard prototype for perishable grocery inventory management.

## Run locally or in Replit

1. Create a new **Node.js** Replit project, or open this project folder.
2. Upload/extract the project files.
3. In the Shell, run:

   ```bash
   npm install
   npm run dev
   ```

4. Open the Vite preview. Replit should expose the app on its web preview.

For a production build:

```bash
npm run build
npm run preview
```

## Prototype features

- Five navigation screens: Dashboard, Inventory, AI Agent Panel, Demand Forecast, Analytics.
- Search and category filtering for 12 sample perishable products.
- Product detail modal with a readable explanation and decision checks.
- Toggleable agent controls and an animated, simulated agent cycle.
- Recharts line, bar, area and pie charts.
- Savings calculator, responsive layout, notification toasts and a collapsible sidebar.
- Demo data only: no backend, external AI calls, real weather API, POS/ERP integration, or persistent storage.

## Demo flow (about 3 minutes)

1. **Dashboard (30 sec):** Show the risk KPIs, demand chart, and activity feed.
2. **Inventory (35 sec):** Search “banana”, click the row, and explain the markdown reasoning.
3. **AI Agent Panel (60 sec):** Toggle an agent, run a cycle, and watch the simulated reasoning sequence.
4. **Demand Forecast (25 sec):** Change the product selector and show the forecast.
5. **Analytics (30 sec):** Move the implementation slider to show the savings estimate changing.

## Important demo note

All numbers, forecasts, model confidence, savings, and agent logs are synthetic demonstration data. They are not live store results or measured real-world impact. The “agent cycle” is a front-end simulation designed to demonstrate the product workflow.
