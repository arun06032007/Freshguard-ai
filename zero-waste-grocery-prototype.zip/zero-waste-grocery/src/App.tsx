import { useMemo, useState } from "react";
import {
  Activity, AlertTriangle, ArrowDownRight, ArrowUpRight, BarChart3, Bell,
  BrainCircuit, CalendarDays, Check, CheckCircle2, ChevronDown, ChevronLeft,
  ChevronRight, CircleHelp, Clock3, CloudRain, Command, Download, Egg, Filter,
  Gauge, Leaf, Lightbulb, Menu, Milk, MoreHorizontal, Package, Play, Search,
  Settings2, ShieldCheck, ShoppingBasket, Sparkles, Sprout, TrendingDown,
  TrendingUp, Truck, Wheat, X, Zap
} from "lucide-react";
import {
  Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, ComposedChart, Line,
  LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis
} from "recharts";

type Product = {
  id: number; name: string; emoji: string; category: string; stock: number;
  capacity: number; days: number; recommendation: string; discount?: number;
  price: number; sold: number; demand: number; waste: number; supplier: string;
  reason: string;
};
type Page = "Dashboard" | "Inventory" | "AI Agent Panel" | "Demand Forecast" | "Analytics";

const initialProducts: Product[] = [
  { id: 1, name: "Bananas", emoji: "🍌", category: "Fresh Produce", stock: 45, capacity: 100, days: 2, recommendation: "Discount 30%", discount: 30, price: 62, sold: 34, demand: 31, waste: 14, supplier: "Green Basket Farms", reason: "Current stock is above the 2-day demand forecast and 45 units have only 48 hours of shelf life. A 30% markdown is projected to move 26 additional units before expiry." },
  { id: 2, name: "Milk 1L", emoji: "🥛", category: "Dairy", stock: 120, capacity: 180, days: 4, recommendation: "Hold", price: 68, sold: 58, demand: 56, waste: 4, supplier: "DairyFresh Co.", reason: "Stock covers approximately 2.1 days of expected demand. Current sell-through is healthy and shelf life is sufficient, so discounting now would unnecessarily reduce margin." },
  { id: 3, name: "Bread Loaf", emoji: "🍞", category: "Bakery", stock: 30, capacity: 80, days: 1, recommendation: "Discount 50%", discount: 50, price: 45, sold: 41, demand: 36, waste: 19, supplier: "Daily Crust Bakery", reason: "Thirty loaves are at risk of expiry tomorrow. A 50% end-of-day markdown is estimated to recover value from stock that would otherwise be discarded." },
  { id: 4, name: "Tomatoes", emoji: "🍅", category: "Fresh Produce", stock: 76, capacity: 120, days: 3, recommendation: "Discount 15%", discount: 15, price: 48, sold: 29, demand: 25, waste: 11, supplier: "Green Basket Farms", reason: "Demand is trending 12% below the weekly average. A small markdown can accelerate sell-through without a steep margin hit." },
  { id: 5, name: "Greek Yogurt", emoji: "🥣", category: "Dairy", stock: 42, capacity: 70, days: 6, recommendation: "Hold", price: 85, sold: 17, demand: 18, waste: 2, supplier: "DairyFresh Co.", reason: "Projected demand and available shelf life are balanced. Keep regular pricing and review again tomorrow." },
  { id: 6, name: "Chicken Breast", emoji: "🍗", category: "Meat", stock: 18, capacity: 65, days: 1, recommendation: "Discount 25%", discount: 25, price: 220, sold: 24, demand: 20, waste: 8, supplier: "FreshCut Meats", reason: "Short shelf life creates high spoilage exposure. Apply a controlled 25% markdown and prioritize this batch in the next picking cycle." },
  { id: 7, name: "Red Apples", emoji: "🍎", category: "Fresh Produce", stock: 93, capacity: 150, days: 8, recommendation: "Hold", price: 140, sold: 22, demand: 24, waste: 3, supplier: "Orchard Lane", reason: "Healthy shelf life and steady demand. Inventory is within target range; no action is needed." },
  { id: 8, name: "Croissants", emoji: "🥐", category: "Bakery", stock: 24, capacity: 60, days: 1, recommendation: "Discount 30%", discount: 30, price: 55, sold: 27, demand: 22, waste: 12, supplier: "Daily Crust Bakery", reason: "Recent sell-through is slower than forecast for this batch. A 30% markdown before closing should reduce end-of-day leftovers." },
  { id: 9, name: "Spinach", emoji: "🥬", category: "Fresh Produce", stock: 16, capacity: 55, days: 2, recommendation: "Reorder Now", price: 35, sold: 20, demand: 23, waste: 6, supplier: "Green Basket Farms", reason: "Projected demand exceeds current stock over the supplier lead-time window. Reorder a small batch, while rotating the current stock first." },
  { id: 10, name: "Cheddar Cheese", emoji: "🧀", category: "Dairy", stock: 52, capacity: 90, days: 18, recommendation: "Hold", price: 125, sold: 13, demand: 15, waste: 1, supplier: "DairyFresh Co.", reason: "Long shelf life and stable demand. Keep current order cadence and avoid overreacting to one day of sales." },
  { id: 11, name: "Ground Beef", emoji: "🥩", category: "Meat", stock: 11, capacity: 50, days: 2, recommendation: "Reorder Now", price: 195, sold: 18, demand: 21, waste: 3, supplier: "FreshCut Meats", reason: "Stock is below the next 24-hour demand estimate. Reorder a small quantity and check current batch rotation before receiving new stock." },
  { id: 12, name: "Strawberries", emoji: "🍓", category: "Fresh Produce", stock: 38, capacity: 75, days: 2, recommendation: "Discount 30%", discount: 30, price: 110, sold: 19, demand: 27, waste: 16, supplier: "Orchard Lane", reason: "Thirty-eight punnets are in stock with only two days of shelf life. Demand alone may not clear the batch; markdown now and consider a transfer if a nearby store has unmet demand." }
];

const demandData = [
  { day: "Mon", actual: 78, predicted: 74 }, { day: "Tue", actual: 83, predicted: 80 },
  { day: "Wed", actual: 69, predicted: 73 }, { day: "Thu", actual: 91, predicted: 88 },
  { day: "Fri", actual: 106, predicted: 101 }, { day: "Sat", actual: 121, predicted: 118 },
  { day: "Sun", actual: 116, predicted: 124 }
];
const forecastData = [
  { day: "Today", demand: 54, low: 47, high: 61 }, { day: "Sat", demand: 58, low: 49, high: 67 },
  { day: "Sun", demand: 66, low: 56, high: 76 }, { day: "Mon", demand: 52, low: 43, high: 61 },
  { day: "Tue", demand: 49, low: 41, high: 57 }, { day: "Wed", demand: 56, low: 46, high: 66 },
  { day: "Thu", demand: 59, low: 48, high: 70 }, { day: "Fri", demand: 63, low: 51, high: 75 }
];
const wasteTrend = [
  { month: "May", waste: 860 }, { month: "Jun", waste: 790 }, { month: "Jul", waste: 720 },
  { month: "Aug", waste: 610 }, { month: "Sep", waste: 520 }, { month: "Oct", waste: 390 }
];
const categoryWaste = [
  { name: "Fresh Produce", value: 42, color: "#52B788" }, { name: "Dairy", value: 24, color: "#82C9A6" },
  { name: "Bakery", value: 19, color: "#F4A261" }, { name: "Meat", value: 15, color: "#E76F51" }
];
const initialActivity = [
  { icon: "discount", title: "Discount recommendation created", detail: "6 bananas · 30% markdown suggested", time: "2 min ago", color: "orange" },
  { icon: "demand", title: "Demand forecast refreshed", detail: "Milk demand expected +22% on Sunday", time: "8 min ago", color: "green" },
  { icon: "stock", title: "Order quantity adjusted", detail: "Milk order reduced by 15% based on trend", time: "16 min ago", color: "blue" },
  { icon: "expiry", title: "Expiry risk detected", detail: "Bread batch B-104 expires tomorrow", time: "24 min ago", color: "red" },
  { icon: "transfer", title: "Transfer opportunity found", detail: "Strawberries: Store A → Store B", time: "31 min ago", color: "purple" }
];
const money = (n: number) => "₹" + Math.round(n).toLocaleString("en-IN");
const shortMoney = (n: number) => n >= 100000 ? `₹${(n / 100000).toFixed(1)}L` : `₹${(n / 1000).toFixed(0)}k`;

function App() {
  const [page, setPage] = useState<Page>("Dashboard");
  const [collapsed, setCollapsed] = useState(false);
  const [mobileNav, setMobileNav] = useState(false);
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("All");
  const [selected, setSelected] = useState<Product | null>(null);
  const [agents, setAgents] = useState([true, true, true]);
  const [running, setRunning] = useState(false);
  const [cycleDone, setCycleDone] = useState(false);
  const [logStep, setLogStep] = useState(3);
  const [forecastProduct, setForecastProduct] = useState("Milk 1L");
  const [toast, setToast] = useState("");
  const [savingsRate, setSavingsRate] = useState(100);
  const [activity, setActivity] = useState(initialActivity);
  const [updated, setUpdated] = useState(false);

  const atRisk = products.filter(p => p.days <= 2).length + 6;
  const recommendations = products.filter(p => p.recommendation !== "Hold").length;
  const filteredProducts = useMemo(() => products.filter(p => {
    const matchesQuery = p.name.toLowerCase().includes(query.toLowerCase());
    const matchesFilter = filter === "All" || p.category === filter;
    return matchesQuery && matchesFilter;
  }), [products, query, filter]);

  function notify(message: string) {
    setToast(message);
    window.setTimeout(() => setToast(""), 2800);
  }

  function runCycle() {
    if (running) return;
    setRunning(true); setCycleDone(false); setLogStep(0);
    const steps = [
      "Scanning inventory and batch shelf-life records…",
      "Comparing 30-day sales patterns with forecast demand…",
      "Evaluating markdowns, replenishment and transfer options…",
      "Validating recommendations against store policies…"
    ];
    let i = 0;
    const tick = () => {
      setLogStep(i + 1);
      if (i < steps.length - 1) { i++; window.setTimeout(tick, 750); }
      else {
        window.setTimeout(() => {
          setProducts(prev => prev.map(p => {
            if (p.days <= 1 && p.recommendation === "Hold") return { ...p, recommendation: "Discount 30%", discount: 30 };
            if (p.name === "Spinach" && p.recommendation === "Reorder Now") return { ...p, stock: Math.min(p.capacity, p.stock + 5) };
            return p;
          }));
          setActivity(prev => [{ icon: "demand", title: "Agent cycle completed", detail: "12 products reviewed · 4 actions validated", time: "Just now", color: "green" }, ...prev].slice(0, 5));
          setRunning(false); setCycleDone(true); setUpdated(true);
          notify("Agent cycle complete — recommendations refreshed.");
        }, 500);
      }
    };
    window.setTimeout(tick, 350);
  }

  function applyRecommendation(product: Product) {
    setProducts(prev => prev.map(p => p.id === product.id ? { ...p, recommendation: "Hold", discount: undefined, stock: p.recommendation === "Reorder Now" ? Math.min(p.capacity, p.stock + 10) : p.stock } : p));
    setSelected(null);
    setActivity(prev => [{ icon: "stock", title: "Action marked as applied", detail: `${product.name} · ${product.recommendation}`, time: "Just now", color: "green" }, ...prev].slice(0, 5));
    notify(`Action recorded for ${product.name}.`);
  }

  const navItems: { label: Page; icon: typeof Gauge; caption: string }[] = [
    { label: "Dashboard", icon: Gauge, caption: "Overview" },
    { label: "Inventory", icon: Package, caption: "Products & expiry" },
    { label: "AI Agent Panel", icon: BrainCircuit, caption: "Autonomous actions" },
    { label: "Demand Forecast", icon: TrendingUp, caption: "Predictive insights" },
    { label: "Analytics", icon: BarChart3, caption: "Waste & savings" }
  ];

  return <div className="app-shell">
    <aside className={`sidebar ${collapsed ? "collapsed" : ""} ${mobileNav ? "mobile-open" : ""}`}>
      <div className="brand">
        <div className="brand-mark"><Sprout size={23} strokeWidth={2.4} /></div>
        {!collapsed && <div className="brand-copy"><strong>zero-waste</strong><span>GROCERY INTELLIGENCE</span></div>}
        <button className="icon-button collapse-btn" onClick={() => setCollapsed(!collapsed)} aria-label="Collapse sidebar"><ChevronLeft size={17}/></button>
      </div>
      <div className="store-switch">
        <div className="store-avatar">G</div>
        {!collapsed && <><div className="store-copy"><b>GreenMart · Downtown</b><span>Store #HYD-042</span></div><ChevronDown size={15} /></>}
      </div>
      <div className="nav-label">{!collapsed && "WORKSPACE"}</div>
      <nav>
        {navItems.map(item => {
          const Icon = item.icon;
          return <button key={item.label} className={`nav-item ${page === item.label ? "active" : ""}`} onClick={() => { setPage(item.label); setMobileNav(false); }}>
            <Icon size={19}/>{!collapsed && <><span>{item.label}</span>{item.label === "AI Agent Panel" && <span className="nav-live-dot" />}</>}
          </button>;
        })}
      </nav>
      {!collapsed && <div className="sidebar-bottom">
        <div className="sidebar-tip"><div className="tip-icon"><Leaf size={17}/></div><b>Small actions. Big impact.</b><p>Every saved item is a step toward a zero-waste future.</p><div className="tip-progress"><span /></div><small>68% of monthly waste goal</small></div>
        <button className="nav-item muted" onClick={() => notify("Settings are demo-only in this prototype.")}><Settings2 size={18}/><span>Settings</span></button>
        <button className="nav-item muted" onClick={() => notify("Help center coming soon.")}><CircleHelp size={18}/><span>Help & support</span></button>
        <div className="profile-row"><div className="profile-avatar">AS</div><div className="profile-copy"><b>Arjun Sharma</b><span>Store manager</span></div><MoreHorizontal size={18}/></div>
      </div>}
    </aside>

    <main className="main-area">
      <header className="topbar">
        <button className="icon-button mobile-menu" onClick={() => setMobileNav(!mobileNav)} aria-label="Open navigation"><Menu size={20}/></button>
        <div className="breadcrumb"><span>Workspace</span><ChevronRight size={14}/><b>{page}</b></div>
        <div className="topbar-actions">
          <div className="status-pill"><span className="pulse-dot"/><span>Agents active</span></div>
          <button className="icon-button notification-button" onClick={() => notify("You're all caught up on notifications.")} aria-label="Notifications"><Bell size={18}/><i /></button>
          <div className="top-avatar">AS</div>
        </div>
      </header>

      <div className="page-content">
        {page === "Dashboard" && <Dashboard products={products} atRisk={atRisk} activity={activity} updated={updated} onNavigate={setPage} onProduct={setSelected} />}
        {page === "Inventory" && <Inventory products={filteredProducts} query={query} setQuery={setQuery} filter={filter} setFilter={setFilter} onProduct={setSelected} onApply={applyRecommendation} />}
        {page === "AI Agent Panel" && <AgentPanel agents={agents} setAgents={setAgents} running={running} cycleDone={cycleDone} logStep={logStep} onRun={runCycle} />}
        {page === "Demand Forecast" && <Forecast product={forecastProduct} setProduct={setForecastProduct} />}
        {page === "Analytics" && <Analytics savingsRate={savingsRate} setSavingsRate={setSavingsRate} products={products} />}
        <footer className="footer"><span><span className="footer-dot"/> All systems operational</span><span>ZERO-WASTE AI <i>·</i> Prototype data is simulated</span></footer>
      </div>
    </main>
    {selected && <ProductModal product={selected} onClose={() => setSelected(null)} onApply={applyRecommendation} />}
    {toast && <div className="toast"><CheckCircle2 size={18}/>{toast}</div>}
  </div>;
}

function PageHeading({ eyebrow, title, description, right }: { eyebrow: string; title: string; description: string; right?: React.ReactNode }) {
  return <div className="page-heading"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{description}</p></div>{right && <div className="heading-right">{right}</div>}</div>;
}

function Dashboard({ products, atRisk, activity, updated, onNavigate, onProduct }: { products: Product[]; atRisk: number; activity: typeof initialActivity; updated: boolean; onNavigate: (p: Page) => void; onProduct: (p: Product) => void }) {
  const totalSaved = updated ? 132850 : 124500;
  const kpis = [
    { label: "Total products", value: "247", note: "Across 5 categories", icon: Package, color: "green", trend: "Inventory tracked" },
    { label: "At-risk items", value: String(atRisk), note: "Expiry within 48 hours", icon: AlertTriangle, color: "amber", trend: "Needs attention" },
    { label: "Waste reduced", value: updated ? "36%" : "34%", note: "vs. baseline this month", icon: Leaf, color: "mint", trend: "+8.2% vs last month" },
    { label: "Revenue saved", value: money(totalSaved), note: "Estimated this month", icon: TrendingUp, color: "blue", trend: "+12.6% vs last month" }
  ];
  return <>
    <PageHeading eyebrow="SATURDAY, OCTOBER 10, 2026" title="Good morning, Arjun 👋" description="Here's what's happening across your perishable inventory today." right={<button className="btn btn-secondary" onClick={() => onNavigate("Analytics")}><Download size={16}/> Export report</button>}/>
    <div className="insight-banner"><div className="insight-icon"><Sparkles size={20}/></div><div><b>Your inventory is looking healthier.</b><p>Smart markdowns have helped protect an estimated <strong>₹18,420</strong> in fresh stock value this week.</p></div><button onClick={() => onNavigate("AI Agent Panel")}>View agent insights <ChevronRight size={15}/></button></div>
    <div className="kpi-grid">
      {kpis.map(k => { const Icon = k.icon; return <div className="kpi-card" key={k.label}><div className={`kpi-icon ${k.color}`}><Icon size={19}/></div><div className="kpi-label">{k.label}<span className="info-dot">i</span></div><div className="kpi-value">{k.value}</div><div className={`kpi-note ${k.color === "amber" ? "warning-note" : ""}`}><span className="kpi-trend">{k.color === "amber" ? <AlertTriangle size={13}/> : <ArrowUpRight size={13}/>} {k.trend}</span><span>{k.note}</span></div></div>; })}
    </div>
    <div className="dashboard-grid">
      <section className="panel demand-panel">
        <div className="panel-heading"><div><h2>Predicted vs. actual demand</h2><p>Units sold · Last 7 days</p></div><button className="select-like" onClick={() => onNavigate("Demand Forecast")}>Last 7 days <ChevronDown size={14}/></button></div>
        <div className="chart-legend"><span><i className="legend-dot actual"/> Actual demand</span><span><i className="legend-dot predicted"/> AI prediction</span></div>
        <div className="chart-area"><ResponsiveContainer width="100%" height="100%"><LineChart data={demandData} margin={{ top: 12, right: 12, left: -18, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#EAF0EC"/><XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fill: "#839188", fontSize: 12 }} dy={10}/><YAxis axisLine={false} tickLine={false} tick={{ fill: "#839188", fontSize: 11 }}/><Tooltip contentStyle={{ borderRadius: 12, border: "1px solid #e3ebe5", boxShadow: "0 8px 24px #163a2a12" }}/><Line type="monotone" dataKey="actual" name="Actual" stroke="#1B4332" strokeWidth={2.5} dot={{ r: 3, fill: "#1B4332", strokeWidth: 0 }} activeDot={{ r: 5 }}/><Line type="monotone" dataKey="predicted" name="Predicted" stroke="#52B788" strokeWidth={2.5} strokeDasharray="5 5" dot={{ r: 3, fill: "#52B788", strokeWidth: 0 }}/></LineChart></ResponsiveContainer></div>
        <div className="chart-bottom"><div><span className="bottom-icon"><TrendingUp size={15}/></span><b>Forecast accuracy</b><strong>92.4%</strong><span className="muted-text"> · this week</span></div><button className="text-button" onClick={() => onNavigate("Demand Forecast")}>Explore forecast <ChevronRight size={15}/></button></div>
      </section>
      <section className="panel activity-panel">
        <div className="panel-heading"><div><h2>AI agent activity</h2><p>Latest decisions & signals</p></div><span className="live-label"><span className="pulse-dot"/> LIVE</span></div>
        <div className="activity-list">{activity.slice(0, 5).map((a, i) => <div className="activity-item" key={`${a.title}-${i}`}><div className={`activity-icon ${a.color}`}>{a.icon === "discount" ? <ShoppingBasket size={16}/> : a.icon === "demand" ? <TrendingUp size={16}/> : a.icon === "stock" ? <Package size={16}/> : a.icon === "expiry" ? <Clock3 size={16}/> : <Truck size={16}/>}</div><div className="activity-copy"><b>{a.title}</b><p>{a.detail}</p><span>{a.time}</span></div></div>)}</div>
        <button className="panel-footer-button" onClick={() => onNavigate("AI Agent Panel")}>Open agent control center <ArrowUpRight size={15}/></button>
      </section>
    </div>
    <section className="panel priority-panel">
      <div className="panel-heading"><div><h2>Needs your attention</h2><p>Prioritized by expiry risk and potential value impact</p></div><button className="text-button" onClick={() => onNavigate("Inventory")}>View all inventory <ChevronRight size={15}/></button></div>
      <div className="priority-list">{products.filter(p => p.days <= 2).slice(0, 4).map(p => <button className="priority-row" key={p.id} onClick={() => onProduct(p)}><div className="product-emoji">{p.emoji}</div><div className="priority-product"><b>{p.name}</b><span>{p.stock} units in stock · {p.days} day{p.days === 1 ? "" : "s"} left</span></div><span className={`rec-badge ${p.recommendation.includes("Discount") ? "discount" : p.recommendation.includes("Reorder") ? "reorder" : "hold"}`}>{p.recommendation}</span><ChevronRight size={16} className="row-arrow"/></button>)}</div>
    </section>
  </>;
}

function Inventory({ products, query, setQuery, filter, setFilter, onProduct, onApply }: { products: Product[]; query: string; setQuery: (v: string) => void; filter: string; setFilter: (v: string) => void; onProduct: (p: Product) => void; onApply: (p: Product) => void }) {
  const tabs = ["All", "Fresh Produce", "Dairy", "Bakery", "Meat"];
  return <>
    <PageHeading eyebrow="STOCK CONTROL" title="Inventory" description="Monitor freshness, stock levels, and AI-recommended actions." right={<button className="btn btn-primary" onClick={() => window.alert("In a live deployment, this would open the stock intake form.")}><Package size={16}/> Add inventory</button>}/>
    <div className="inventory-summary"><div><span className="summary-icon green"><Package size={17}/></span><span><b>247</b><small>Active SKUs</small></span></div><div><span className="summary-icon amber"><AlertTriangle size={17}/></span><span><b>18</b><small>At expiry risk</small></span></div><div><span className="summary-icon mint"><Zap size={17}/></span><span><b>{products.filter(p => p.recommendation !== "Hold").length}</b><small>AI actions suggested</small></span></div><div><span className="summary-icon blue"><CheckCircle2 size={17}/></span><span><b>96.8%</b><small>Stock data health</small></span></div></div>
    <section className="panel inventory-panel">
      <div className="inventory-tools"><div className="search-box"><Search size={17}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search products..." /><kbd>⌘ K</kbd></div><button className="btn btn-secondary filter-button" onClick={() => setFilter(filter === "All" ? "Fresh Produce" : "All")}><Filter size={15}/> Filter <ChevronDown size={14}/></button><button className="icon-button table-more" aria-label="More options"><MoreHorizontal size={18}/></button></div>
      <div className="filter-tabs">{tabs.map(t => <button key={t} onClick={() => setFilter(t)} className={filter === t ? "selected" : ""}>{t}{t === "All" && <span>12</span>}</button>)}</div>
      <div className="table-wrap"><table className="inventory-table"><thead><tr><th>PRODUCT</th><th>STOCK LEVEL</th><th>SHELF LIFE</th><th>AI RECOMMENDATION</th><th></th></tr></thead><tbody>{products.map(p => <tr key={p.id} onClick={() => onProduct(p)}><td><div className="table-product"><div className="table-emoji">{p.emoji}</div><div><b>{p.name}</b><span>{p.category}</span></div></div></td><td><div className="stock-cell"><div className="stock-numbers"><b>{p.stock} units</b><span>{Math.round(p.stock / p.capacity * 100)}%</span></div><div className="stock-track"><span style={{ width: `${Math.min(100, p.stock / p.capacity * 100)}%` }} className={p.stock / p.capacity < .3 ? "low" : p.stock / p.capacity > .75 ? "high" : ""}/></div></div></td><td><span className={`shelf-life ${p.days < 2 ? "danger" : p.days <= 5 ? "warning" : "safe"}`}><span/>{p.days} day{p.days === 1 ? "" : "s"}</span></td><td><span className={`rec-badge ${p.recommendation.includes("Discount") ? "discount" : p.recommendation.includes("Reorder") ? "reorder" : "hold"}`}>{p.recommendation}</span></td><td><button className="row-action" onClick={e => { e.stopPropagation(); onProduct(p); }}><ChevronRight size={17}/></button></td></tr>)}</tbody></table></div>
      {products.length === 0 && <div className="empty-state"><Search size={25}/><b>No products found</b><span>Try a different search or category.</span></div>}
      <div className="table-bottom"><span>Showing <b>{products.length}</b> of <b>12</b> demo products</span><div><button className="pager-btn" disabled><ChevronLeft size={15}/></button><button className="pager-btn current">1</button><button className="pager-btn" disabled><ChevronRight size={15}/></button></div></div>
    </section>
  </>;
}

function AgentPanel({ agents, setAgents, running, cycleDone, logStep, onRun }: { agents: boolean[]; setAgents: (v: boolean[]) => void; running: boolean; cycleDone: boolean; logStep: number; onRun: () => void }) {
  const [showAll, setShowAll] = useState(false);
  const logs = [
    { time: "10:22:41", icon: <Search size={15}/>, text: "Scanning inventory…", detail: "18 items identified as at-risk", tone: "green" },
    { time: "10:22:42", icon: <BarChart3 size={15}/>, text: "Analyzing demand patterns", detail: "Comparing 30-day sales and weekend trend", tone: "blue" },
    { time: "10:22:43", icon: <CloudRain size={15}/>, text: "Weather signal evaluated", detail: "Rain forecast this weekend · outdoor produce demand may soften", tone: "orange" },
    { time: "10:22:44", icon: <ShieldCheck size={15}/>, text: "Decision policy validation", detail: "Discount limits and stock thresholds checked", tone: "purple" },
    { time: "10:22:45", icon: <CheckCircle2 size={15}/>, text: "Recommendation ready", detail: "Apply dynamic pricing to 6 products", tone: "green" }
  ];
  const agentCards = [
    { title: "Demand Predictor", subtitle: "Forecasts demand 7 days ahead", description: "Learns from recent sales velocity, weekday patterns and seasonality to estimate what customers will buy.", icon: TrendingUp, color: "green", metric: "7-day horizon" },
    { title: "Expiry Watchdog", subtitle: "Flags items within 48 hours of expiry", description: "Checks batch shelf life against projected sell-through and prioritizes stock with the highest spoilage exposure.", icon: Clock3, color: "orange", metric: "48h risk window" },
    { title: "Dynamic Pricing", subtitle: "Suggests markdowns to protect value", description: "Balances remaining shelf life, demand and margin guardrails to recommend a controlled discount.", icon: Zap, color: "purple", metric: "Margin-aware" }
  ];
  return <>
    <PageHeading eyebrow="AUTONOMOUS OPERATIONS" title="AI Agent Control Center" description="A coordinated team of specialized agents, working toward less waste and smarter stock decisions." right={<span className="simulation-tag"><Activity size={14}/> SIMULATION MODE</span>}/>
    <div className="agent-hero"><div className="agent-hero-orb"><BrainCircuit size={29}/><span/></div><div className="agent-hero-copy"><div className="hero-status"><span className="pulse-dot"/> MULTI-AGENT SYSTEM {agents.some(Boolean) ? "OPERATIONAL" : "PAUSED"}</div><h2>Your inventory, continuously optimized.</h2><p>Agents analyze stock, forecast demand, and propose actions. Every recommendation is checked against store policy before it reaches your team.</p><div className="hero-mini-stats"><span><b>{agents.filter(Boolean).length}/3</b> agents enabled</span><i/><span><b>12</b> products reviewed</span><i/><span><b>4</b> actions queued</span></div></div><div className="hero-run"><button className="btn btn-light" onClick={onRun} disabled={running}>{running ? <><span className="button-spinner"/> Running cycle</> : <><Play size={16} fill="currentColor"/> Run agent cycle</>}</button><small>Last run: {cycleDone ? "just now" : "8 minutes ago"}</small></div></div>
    <div className="section-title-row"><div><h2>Agent configuration</h2><p>Toggle each agent to control its role in the next cycle.</p></div><button className="text-button" onClick={() => setAgents([true, true, true])}><Settings2 size={15}/> Reset defaults</button></div>
    <div className="agent-card-grid">{agentCards.map((a, i) => { const Icon = a.icon; return <div className={`agent-card ${!agents[i] ? "disabled-agent" : ""}`} key={a.title}><div className="agent-card-top"><div className={`agent-icon ${a.color}`}><Icon size={21}/></div><button className={`toggle ${agents[i] ? "on" : ""}`} onClick={() => setAgents(agents.map((v, idx) => idx === i ? !v : v))} aria-label={`Toggle ${a.title}`}><span/></button></div><div className="agent-card-state"><span className={agents[i] ? "state-on" : "state-off"}><i/>{agents[i] ? "ACTIVE" : "PAUSED"}</span><span className="agent-metric">{a.metric}</span></div><h3>{a.title} Agent</h3><b className="agent-subtitle">{a.subtitle}</b><p>{a.description}</p><div className="agent-card-foot"><span><span className="mini-live-dot"/> {agents[i] ? "Monitoring" : "Not monitoring"}</span><ChevronRight size={16}/></div></div>; })}</div>
    <div className="agent-bottom-grid">
      <section className="panel reasoning-panel"><div className="panel-heading"><div><h2><span className="heading-spark"><Sparkles size={16}/></span> Live reasoning log</h2><p>Recent system observations and decisions</p></div><span className="live-label"><span className="pulse-dot"/> LIVE</span></div>
        <div className="reasoning-log">{(showAll ? logs : logs.slice(-4)).map((l, i) => <div className="log-row" key={l.text}><div className={`log-icon ${l.tone}`}>{l.icon}</div><div className="log-copy"><b>{l.text}</b><span>{l.detail}</span></div><time>{running ? (i < logStep ? "now" : "queued") : l.time}</time></div>)}
          {running && <div className="cycle-progress"><span className="button-spinner"/> Agent cycle in progress… {Math.min(logStep, 4)}/4 steps</div>}
          {cycleDone && <div className="cycle-success"><CheckCircle2 size={16}/> Cycle completed. Recommendations and inventory state refreshed.</div>}
        </div><button className="panel-footer-button" onClick={() => setShowAll(!showAll)}>{showAll ? "Show recent events" : "View all activity"} <ChevronRight size={15}/></button>
      </section>
      <section className="panel action-queue"><div className="panel-heading"><div><h2>Pending decisions</h2><p>Recommended actions awaiting review</p></div><span className="queue-count">4</span></div>
        {[{emoji:"🍌",name:"Bananas",detail:"30% markdown · 45 units",badge:"HIGH PRIORITY"},{emoji:"🍞",name:"Bread loaf",detail:"50% markdown · 30 units",badge:"EXPIRING SOON"},{emoji:"🍓",name:"Strawberries",detail:"Transfer or markdown · 38 units",badge:"REVIEW"},{emoji:"🥛",name:"Milk 1L",detail:"Reduce next order by 15%",badge:"LOW RISK"}].map((x,i)=><div className="queue-row" key={x.name}><span className="queue-emoji">{x.emoji}</span><div className="queue-copy"><b>{x.name}</b><span>{x.detail}</span></div><span className={`queue-priority priority-${i}`}>{x.badge}</span></div>)}
        <button className="btn btn-primary queue-button" onClick={onRun}><Zap size={15}/> Re-evaluate all actions</button>
      </section>
    </div>
  </>;
}

function Forecast({ product, setProduct }: { product: string; setProduct: (v: string) => void }) {
  const [range, setRange] = useState("7 days");
  const selectedProduct = initialProducts.find(p => p.name === product) || initialProducts[1];
  const scale = selectedProduct.name === "Milk 1L" ? 1 : selectedProduct.name === "Bananas" ? .7 : selectedProduct.name === "Bread Loaf" ? .62 : 1.12;
  const data = forecastData.map(d => ({ ...d, demand: Math.round(d.demand * scale), low: Math.round(d.low * scale), band: Math.round((d.high - d.low) * scale), high: Math.round(d.high * scale) }));
  return <>
    <PageHeading eyebrow="PREDICTIVE INTELLIGENCE" title="Demand forecast" description="Understand what customers are likely to buy — before you place the next order." right={<button className="btn btn-secondary"><CalendarDays size={16}/> Next 7 days <ChevronDown size={14}/></button>}/>
    <div className="forecast-controls"><label>PRODUCT TO FORECAST<select value={product} onChange={e => setProduct(e.target.value)}>{initialProducts.map(p => <option key={p.id}>{p.name}</option>)}</select></label><div className="forecast-meta"><span className="model-status"><span className="pulse-dot"/> Forecast model ready</span><span>Last updated 10:14 AM</span></div></div>
    <div className="forecast-kpis"><div className="forecast-stat"><span>Expected daily demand</span><b>{Math.round(56 * scale)} <small>units</small></b><em className="positive"><ArrowUpRight size={13}/> 8.4% vs last week</em></div><div className="forecast-stat"><span>Peak demand day</span><b>Sunday</b><em>+22% above daily average</em></div><div className="forecast-stat"><span>Recommended safety stock</span><b>{Math.round(18 * scale)} <small>units</small></b><em>Based on forecast variability</em></div><div className="forecast-stat"><span>Model confidence</span><b>92.4%</b><em>Good confidence · 30-day history</em></div></div>
    <section className="panel forecast-chart-panel"><div className="panel-heading"><div><h2>7-day demand prediction</h2><p>Forecast with estimated uncertainty band · Units per day</p></div><div className="chart-legend"><span><i className="legend-dot predicted"/> Predicted demand</span><span><i className="legend-band"/> Confidence range</span></div></div>
      <div className="forecast-chart"><ResponsiveContainer width="100%" height="100%"><ComposedChart data={data} margin={{ top: 12, right: 16, left: -16, bottom: 0 }}><defs><linearGradient id="confidenceFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#52B788" stopOpacity={0.24}/><stop offset="100%" stopColor="#52B788" stopOpacity={0.03}/></linearGradient></defs><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#EAF0EC"/><XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fill: "#839188", fontSize: 12 }} dy={10}/><YAxis axisLine={false} tickLine={false} tick={{ fill: "#839188", fontSize: 11 }}/><Tooltip contentStyle={{ borderRadius: 12, border: "1px solid #e3ebe5" }}/><Area type="monotone" dataKey="high" stroke="none" fill="url(#confidenceFill)" name="Upper estimate"/><Area type="monotone" dataKey="low" stroke="none" fill="#fff" fillOpacity={1} name="Lower estimate"/><Line type="monotone" dataKey="demand" stroke="#1B4332" strokeWidth={3} dot={{ r: 4, fill: "#52B788", stroke: "#fff", strokeWidth: 2 }} activeDot={{ r: 6 }} name="Predicted demand"/></ComposedChart></ResponsiveContainer></div>
      <div className="forecast-chart-foot"><span><i className="legend-dot predicted"/> Model prediction</span><span><i className="legend-band"/> Range shows expected uncertainty, not a guarantee</span></div>
    </section>
    <div className="forecast-bottom-grid"><section className="panel factors-panel"><div className="panel-heading"><div><h2>What influences this forecast?</h2><p>Signals considered by the demand agent</p></div></div>{[{icon:<BarChart3 size={17}/>,name:"Historical sales",detail:"30-day sell-through and recent velocity",weight:42},{icon:<CalendarDays size={17}/>,name:"Day of week",detail:"Weekend shopping pattern",weight:26},{icon:<CloudRain size={17}/>,name:"Weather signal",detail:"Rain forecast may shift store traffic",weight:14},{icon:<Egg size={17}/>,name:"Seasonality & holidays",detail:"Local calendar and seasonal patterns",weight:11},{icon:<Activity size={17}/>,name:"Local events",detail:"Event signal currently low impact",weight:7}].map(f=><div className="factor-row" key={f.name}><div className="factor-icon">{f.icon}</div><div className="factor-copy"><b>{f.name}</b><span>{f.detail}</span></div><div className="factor-weight"><div><span style={{width:`${f.weight}%`}}/></div><b>{f.weight}%</b></div></div>)}</section>
      <section className="ai-insight-card"><div className="ai-insight-top"><div className="insight-icon"><Lightbulb size={19}/></div><span>AI INSIGHT</span></div><h3>Plan ahead for Sunday.</h3><p>Demand for <b>{product.toLowerCase()}</b> is expected to rise by <strong>22%</strong> on Sunday. Consider a small replenishment ahead of the weekend while keeping an eye on shelf life.</p><div className="insight-recommendation"><span><CheckCircle2 size={16}/></span><div><b>Suggested action</b><p>Review order quantity by Friday, 4 PM.</p></div></div><button className="btn btn-primary" onClick={() => window.alert(`Order review queued for ${product}.`)}>Review order plan <ChevronRight size={15}/></button></section></div>
  </>;
}

function Analytics({ savingsRate, setSavingsRate, products }: { savingsRate: number; setSavingsRate: (n: number) => void; products: Product[] }) {
  const savings = Math.round(124500 * savingsRate / 100);
  const wasted = [...products].sort((a,b) => b.waste - a.waste).slice(0,5);
  return <>
    <PageHeading eyebrow="IMPACT & PERFORMANCE" title="Analytics" description="Measure waste trends, understand loss drivers, and estimate the value of better decisions." right={<button className="btn btn-secondary" onClick={() => window.print()}><Download size={16}/> Export analytics</button>}/>
    <div className="analytics-top-stats"><div className="analytics-stat"><div className="analytics-stat-icon mint"><Leaf size={18}/></div><span>Waste reduction vs baseline</span><b>34.0%</b><em><ArrowUpRight size={13}/> 8.2% over last month</em></div><div className="analytics-stat"><div className="analytics-stat-icon green"><ShoppingBasket size={18}/></div><span>Estimated value recovered</span><b>₹1,24,500</b><em><ArrowUpRight size={13}/> 12.6% over last month</em></div><div className="analytics-stat"><div className="analytics-stat-icon orange"><Package size={18}/></div><span>Potential waste avoided</span><b>1,286 <small>items</small></b><em>Modelled monthly estimate</em></div><div className="analytics-stat"><div className="analytics-stat-icon blue"><ShieldCheck size={18}/></div><span>Recommendation follow-through</span><b>78.4%</b><em>Actions marked as completed</em></div></div>
    <div className="analytics-grid"><section className="panel waste-trend-panel"><div className="panel-heading"><div><h2>Waste volume over time</h2><p>Estimated discarded units · Monthly</p></div><span className="trend-chip"><TrendingDown size={14}/> −54.7%</span></div><div className="analytics-chart"><ResponsiveContainer width="100%" height="100%"><BarChart data={wasteTrend} margin={{top:10,right:8,left:-18,bottom:0}}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#EAF0EC"/><XAxis dataKey="month" axisLine={false} tickLine={false} tick={{fill:"#839188",fontSize:12}} dy={10}/><YAxis axisLine={false} tickLine={false} tick={{fill:"#839188",fontSize:11}}/><Tooltip contentStyle={{borderRadius:12,border:"1px solid #e3ebe5"}}/><Bar dataKey="waste" name="Discarded units" fill="#52B788" radius={[6,6,0,0]} maxBarSize={42}/></BarChart></ResponsiveContainer></div><div className="chart-footnote"><span><i className="legend-dot predicted"/> Simulated waste volume</span><span>May–Oct 2026</span></div></section>
      <section className="panel category-panel"><div className="panel-heading"><div><h2>Waste by category</h2><p>Share of recorded spoilage</p></div><button className="icon-button" aria-label="More category options"><MoreHorizontal size={18}/></button></div><div className="donut-wrap"><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={categoryWaste} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={62} outerRadius={88} paddingAngle={3} stroke="none">{categoryWaste.map((c,i)=><Cell key={c.name} fill={c.color}/>)}</Pie><Tooltip formatter={(value) => `${value}%`}/></PieChart></ResponsiveContainer><div className="donut-center"><b>100%</b><span>of waste</span></div></div><div className="category-legend">{categoryWaste.map(c=><div key={c.name}><i style={{background:c.color}}/><span>{c.name}</span><b>{c.value}%</b></div>)}</div></section></div>
    <div className="analytics-bottom-grid"><section className="panel wasted-products-panel"><div className="panel-heading"><div><h2>Most wasted products</h2><p>Ranked by estimated discarded units in the sample</p></div><span className="risk-tag">TOP 5</span></div>{wasted.map((p,i)=><div className="wasted-row" key={p.id}><span className="wasted-rank">{String(i+1).padStart(2,"0")}</span><span className="wasted-emoji">{p.emoji}</span><div className="wasted-name"><b>{p.name}</b><span>{p.category}</span></div><div className="wasted-bar"><span style={{width:`${p.waste/Math.max(...wasted.map(x=>x.waste))*100}%`}}/></div><b className="wasted-count">{p.waste} <small>units</small></b></div>)}</section>
      <section className="savings-card"><div className="savings-card-top"><div className="savings-icon"><Sprout size={20}/></div><span>IMPACT CALCULATOR</span></div><h2>What could you save?</h2><p>Estimate monthly value recovery if your team implements more of the AI recommendations.</p><div className="savings-amount">{money(savings)}<span>/ month</span></div><div className="slider-label"><span>Recommendations implemented</span><b>{savingsRate}%</b></div><input className="savings-slider" type="range" min="10" max="100" step="10" value={savingsRate} onChange={e=>setSavingsRate(Number(e.target.value))}/><div className="slider-ends"><span>10%</span><span>100%</span></div><div className="savings-note"><Lightbulb size={15}/> Estimate based on simulated baseline savings; actual results will vary.</div></section></div>
  </>;
}

function ProductModal({ product, onClose, onApply }: { product: Product; onClose: () => void; onApply: (p: Product) => void }) {
  return <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}><div className="product-modal"><div className="modal-head"><div><div className="eyebrow">PRODUCT INTELLIGENCE</div><h2>AI decision detail</h2></div><button className="icon-button" onClick={onClose} aria-label="Close modal"><X size={19}/></button></div><div className="modal-product"><div className="modal-emoji">{product.emoji}</div><div><h3>{product.name}</h3><span>{product.category} · SKU ZWG-{String(product.id).padStart(4,"0")}</span></div><span className={`rec-badge ${product.recommendation.includes("Discount") ? "discount" : product.recommendation.includes("Reorder") ? "reorder" : "hold"}`}>{product.recommendation}</span></div>
    <div className="modal-metrics"><div><span>Current stock</span><b>{product.stock} units</b></div><div><span>Shelf life left</span><b className={product.days <= 2 ? "text-danger" : ""}>{product.days} days</b></div><div><span>Unit price</span><b>{money(product.price)}</b></div></div>
    <div className="reasoning-box"><div><Sparkles size={16}/><b>Why this action?</b></div><p>{product.reason}</p></div>
    <div className="decision-steps"><h4>Decision checks</h4><div><CheckCircle2 size={16}/><span>Demand forecast reviewed</span><b>Passed</b></div><div><CheckCircle2 size={16}/><span>Shelf-life risk assessed</span><b>Passed</b></div><div><CheckCircle2 size={16}/><span>Store policy constraints</span><b>Passed</b></div></div>
    <div className="modal-foot"><span><ShieldCheck size={15}/> Manager review required · Demo mode</span><button className="btn btn-primary" onClick={() => onApply(product)}><Check size={16}/> Mark action applied</button></div>
  </div></div>;
}

export default App;
